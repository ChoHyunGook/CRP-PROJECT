# -*- coding: utf-8 -*-
from music21.languageExcerpts import instrumentLookup
from music21.languageExcerpts import naturalLanguageObjects
