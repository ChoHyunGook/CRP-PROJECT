# -*- coding: utf-8 -*-

_DOC_IGNORE_MODULE_OR_PACKAGE = True

